# Notebook 1: Loading and Preprocessing a Corpus from Project Gutenberg

# --- Setup ---
!pip install gutenbergpy --quiet
!pip install nltk --quiet

import os
import re
from gutenbergpy.gutenbergcache import GutenbergCache
from gutenbergpy.textget import get_text_by_id
from nltk.tokenize import sent_tokenize, word_tokenize
import nltk
nltk.download('punkt')

# --- Step 1: Download and extract a book from Project Gutenberg ---
# We'll use "Frankenstein" by Mary Shelley (Gutenberg ID: 84)
book_id = 84
raw_text = get_text_by_id(book_id).decode('utf-8')

# --- Step 2: Clean the text ---
def strip_headers(text):
    start_re = re.compile(r'\*\*\* START OF THIS PROJECT GUTENBERG EBOOK .* \*\*\*')
    end_re = re.compile(r'\*\*\* END OF THIS PROJECT GUTENBERG EBOOK .* \*\*\*')
    start_match = start_re.search(text)
    end_match = end_re.search(text)
    start = start_match.end() if start_match else 0
    end = end_match.start() if end_match else len(text)
    return text[start:end].strip()

clean_text = strip_headers(raw_text)

# --- Step 3: Sentence and word tokenization ---
sentences = sent_tokenize(clean_text)
tokenized_sentences = [word_tokenize(sent) for sent in sentences]

# --- Step 4: Save outputs ---
os.makedirs("data", exist_ok=True)
with open("data/frankenstein_clean.txt", "w", encoding="utf-8") as f:
    f.write(clean_text)

with open("data/frankenstein_tokenized.txt", "w", encoding="utf-8") as f:
    for sent in tokenized_sentences:
        f.write(" ".join(sent) + "\n")

# --- Display a preview ---
print("Sample sentence:", sentences[0])
print("Tokenized:", tokenized_sentences[0])