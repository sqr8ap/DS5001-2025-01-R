# Notebook 4: Lab Guide – Exploring LLMs with Gutenberg Texts

"""
This notebook ties together the previous three:
1. Corpus preparation
2. Embedding similarity with BERT
3. Text generation with GPT-2

Includes exercises and prompts for critical reflection.
"""

from IPython.display import Markdown

def section(title):
    display(Markdown(f"## {title}"))

def question(prompt):
    display(Markdown(f"**Exercise:** {prompt}"))

# --- Intro ---
section("Welcome to the LLM Lab")
Markdown("""
In this lab, you'll explore how Large Language Models (LLMs) can be used to process and generate text from a classic novel: *Frankenstein* by Mary Shelley.
You'll complete three tasks:
1. Load and preprocess the corpus
2. Analyze passages using sentence embeddings
3. Generate new text based on story prompts
""")

# --- Task 1: Corpus Loading ---
section("Task 1: Load and Clean the Corpus")
Markdown("""
Re-run the notebook `notebook_gutenberg_corpus.py` or execute the relevant cells here.
After tokenizing the text, consider:
""")
question("What are the challenges of cleaning historical or literary texts for NLP tasks?")
question("How does sentence segmentation affect downstream analysis?")

# --- Task 2: Embedding Similarity ---
section("Task 2: Embedding Similarity with DistilBERT")
Markdown("""
Now run the `notebook_embeddings_bert.py`. Examine the similarity matrix.
""")
question("Which passages are most similar? Why?")
question("Do similar embeddings reflect semantic similarity, stylistic similarity, or something else?")
question("What limitations do you notice in BERT's representation of paragraphs from literature?")

# --- Task 3: Prompt-based Text Generation ---
section("Task 3: Prompt-based Text Generation")
Markdown("""
Run the `notebook_gpt2_generation.py`.
Experiment with writing your own prompts.
""")
question("Try three different prompts. What factors influence the coherence and creativity of the completions?")
question("How might you use a generative model in close reading or literary analysis?")

# --- Wrap-up ---
section("Reflection and Extension")
question("Compare embedding-based similarity and generation. How do they reflect different affordances of LLMs?")
question("What ethical considerations arise when using generative AI for textual work?")
question("How might these tools shape how we read and write?")