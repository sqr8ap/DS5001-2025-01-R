# Notebook 3: Text Generation with GPT-2

# --- Setup ---
!pip install transformers --quiet
!pip install torch --quiet

from transformers import GPT2LMHeadModel, GPT2Tokenizer
import torch

# --- Load GPT-2 ---
model_name = "distilgpt2"
tokenizer = GPT2Tokenizer.from_pretrained(model_name)
model = GPT2LMHeadModel.from_pretrained(model_name)
model.eval()

# --- Define generation function ---
def generate_text(prompt, max_length=50, num_return_sequences=1):
    inputs = tokenizer(prompt, return_tensors="pt")
    with torch.no_grad():
        outputs = model.generate(
            **inputs,
            max_length=max_length,
            num_return_sequences=num_return_sequences,
            do_sample=True,
            top_k=50,
            top_p=0.95,
            temperature=0.9
        )
    return [tokenizer.decode(g, skip_special_tokens=True) for g in outputs]

# --- Example prompts ---
prompts = [
    "Once upon a time in the Alps,",
    "Victor Frankenstein looked down at his creation and said,",
    "In a world governed by artificial intelligence, humans had to learn to"
]

# --- Generate and display results ---
for i, prompt in enumerate(prompts):
    print(f"\nPrompt {i+1}: {prompt}")
    completions = generate_text(prompt, max_length=60)
    for j, comp in enumerate(completions):
        print(f"\nGenerated {j+1}: {comp}")