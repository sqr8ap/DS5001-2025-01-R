# Notebook 2: Embeddings and Similarity with DistilBERT

# --- Setup ---
!pip install transformers --quiet
!pip install torch --quiet
!pip install scikit-learn --quiet

import torch
from transformers import AutoTokenizer, AutoModel
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np

# --- Load DistilBERT ---
model_name = "distilbert-base-uncased"
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModel.from_pretrained(model_name)
model.eval();

# --- Define a helper to compute embeddings ---
def get_embedding(text):
    inputs = tokenizer(text, return_tensors="pt", truncation=True, padding=True)
    with torch.no_grad():
        outputs = model(**inputs)
    return outputs.last_hidden_state[:, 0, :].numpy()  # Use [CLS] token embedding

# --- Load a few lines from cleaned Frankenstein text ---
with open("data/frankenstein_clean.txt", encoding="utf-8") as f:
    lines = [line.strip() for line in f if line.strip() != ""]

sample_passages = lines[:5]  # Choose first five paragraphs for demo

# --- Compute embeddings ---
embeddings = np.vstack([get_embedding(p) for p in sample_passages])

# --- Pairwise similarity ---
sim_matrix = cosine_similarity(embeddings)

# --- Display results ---
import pandas as pd
pd.set_option("display.max_colwidth", 100)

similarity_df = pd.DataFrame(sim_matrix, index=[f"P{i+1}" for i in range(len(sample_passages))],
                              columns=[f"P{i+1}" for i in range(len(sample_passages))])

from IPython.display import display
print("Sample Passages:")
for i, p in enumerate(sample_passages):
    print(f"P{i+1}: {p[:80]}...")

print("\nCosine Similarity Matrix:")
display(similarity_df.round(2))